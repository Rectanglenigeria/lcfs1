/*
Name: 			App Landing
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version:	6.0.0
*/

(function( $ ) {

	

}).apply( this, [ jQuery ]);