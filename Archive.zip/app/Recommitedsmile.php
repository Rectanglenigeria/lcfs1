<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Recommitedsmile extends Model
{
    //
}
