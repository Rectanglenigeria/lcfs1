<!doctype html>
<html class="no-js" lang="en-US">

<!-- Mirrored from demos.hogash.com/Smilesteadily_template/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 07 Jul 2017 10:09:48 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<!-- meta -->
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1">

	<!-- Uncomment the meta tags you are going to use! Be relevant and don't spam! -->

	<meta name="keywords" content="premium html template, unique premium template, multipurpose template" />
	<meta name="description" content="Smilesteadily is an ultra-premium, responsive theme built for todays websites. Create your website, fast.">

	<!-- Title -->
	<title>Smilesteadily </title>

	

	<!--  Desktop Favicons  -->
	<link rel="icon" type="image/png" href="images/favicons/favicon-16x16.png" sizes="16x16">
	<!-- <link rel="icon" type="image/png" href="images/favicons/favicon-32x32.png" sizes="32x32"> -->
	<!-- <link rel="icon" type="image/png" href="images/favicons/favicon-96x96.png" sizes="96x96"> -->

	<!-- Google Fonts CSS Stylesheet // More here http://www.google.com/fonts#UsePlace:use/Collection:Open+Sans -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400italic,400,600,600italic,700,800,800italic" rel="stylesheet" type="text/css">
	<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

	<!-- ***** Boostrap Custom / Addons Stylesheets ***** -->
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="all">

	<!-- Required CSS file for iOS Slider element -->
	<link rel="stylesheet" href="css/sliders/ios/style.css" type="text/css" media="all">

	<!-- ***** Main + Responsive & Base sizing CSS Stylesheet ***** -->
	<link rel="stylesheet" href="css/template.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/responsive.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/base-sizing.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/dp.css" type="text/css" media="all">
	

	<!-- Modernizr Library -->
	<script type="text/javascript" src="js/modernizr.min.js"></script>

	<!-- jQuery Library -->
	<script type="text/javascript" src="js/jquery.js"></script>
  
  <style>
  @media only screen and (max-width: 600px)
    {
      .header-links-container
      {
      display: none;
      }
    }

    
  @media only screen and (min-width: 500px)
    {
      
      .left-seeding
      {
        display: none;
      }
      
    }
    
    .left-seeding
    {
      color: white;
    }
    .myClass
      {
        margin: 0 0;
        color: #ffffff;
        list-style-type: none;  
      }
      .myClass  li
      {
        display: inline-block;
        color: #fff;
      }
      .myClass li a
      {
        color: floralwhite;
      }

  </style>

</head>

<body class="">
	

		<!-- Page Wrapper -->
	<div id="page_wrapper">
		<div id="dp-js-header-helper" style="height:0 !important; display:none !important;"></div>
<!-- Header style 1 -->
<header id="header" class="site-header style1 cta_button">
	<!-- header bg -->
<!--	<div class="kl-header-bg"></div>-->
	<!--/ header bg -->

	<!-- siteheader-container -->
	<div class="container siteheader-container">
		<!-- top-header -->
<!--		<div class="kl-top-header clearfix">-->
			<!-- HEADER ACTION -->
			<div class="header-links-container ">
				<ul class="topnav navRight topnav">
					<!-- Support panel trigger -->
                  
                  <li>
						<label for="support_p" class="spanel-label">
                    		<i class="glyphicon glyphicon-info-sign icon-white support-info visible-xs xs-icon"></i>
							<span class="hidden-xl"><a href="index.html">SIGN UP</a></span>
						</label>
					</li>

					<!--/ Support panel trigger -->

					<!-- Login trigger -->
					<li>
						<a class="popup-with-form" href="#login_panel">
							<i class="glyphicon glyphicon-log-in visible-xs xs-icon"></i>
							<span class="hidden-xl">LOGIN</span>
						</a>
					</li>
					<!--/ Login trigger -->			
				</ul>
              
				<!--/ Languages -->

				<!-- header search -->
<!--
				<div id="search" class="header-search">
					<a href="#" class="searchBtn "><span class="glyphicon glyphicon-search icon-white"></span></a>
					<div class="search-container">
						<form id="searchform" class="header-searchform" action="https://www.google.ro/search" method="get" target="_blank">
						<input type="hidden" id="q" name="q"/>
							<input name="s" maxlength="20" class="inputbox" type="text" size="20" value="SEARCH ..." onblur="if (this.value=='') this.value='SEARCH ...';" onfocus="if (this.value=='SEARCH ...') this.value='';">
							<button type="submit" id="searchsubmit" class="searchsubmit glyphicon glyphicon-search icon-white"></button>
						</form>
					</div>
				</div>
-->
				<!--/ header search -->
			</div>
			<!--/ HEADER ACTION -->

			<!-- HEADER ACTION left -->
			<div class="header-leftside-container ">
				<!-- Header Social links -->
				<!--/ Header Social links -->

<!--				<div class="clearfix visible-xxs">-->
<!--				</div>-->

				<!-- header contact text -->


              <div class="left-seeding">

              <ul class="myClass">
					 

					<li>
						<label for="support_p" class="spanel-label">                   		
                          <span class="default "><a href="index.html" class="">Home </a></span>
                      </label>
					</li>
                    
                    <li>
				      <label for="support_p" class="spanel-label">
                    		
                          <span class=" "><a href="about-me.html" class="">About Us</a></span>
				      </label>
					</li>
                
                  <li>
				      <label for="support_p" class="spanel-label">
                    		
                          <span class=" "><a href="contact-us.html" class="">Contact Us</a></span>
				      </label>
				</li>
                
                
                <li>
				      <label for="support_p" class="spanel-label">
                    		
                          <span class=" "><a href="index.html" class="">How It Works</a></span>
				      </label>
				</li>
                
                <li>
				      <label for="support_p" class="spanel-label">
                    		
                          <span class=" "><a href="index.html" class="">Faqs</a></span>
				      </label>
				</li>
                
                <li>
				      <label for="support_p" class="spanel-label">
                    		
                          <span class=" "><a href="index.html" class="">Testimonials</a></span>
				      </label>
				</li>
              </ul>

<hr>
				
				<!--/ header contact text -->
			</div>
			<!--/ HEADER ACTION left -->
		</div>
		<!--/ top-header -->
		
		<!-- separator -->
		<!--/ separator -->

		<!-- left side -->
		<!-- logo container-->

		<div class="logo-container hasInfoCard logosize--yes">
			 
			<h1 class="site-logo logo" id="logo">
				<a href="index.html" title="">
					<img src="images/smilelog.png" class="logo-img" alt="Smile Steadily" title="Smiles steadily" style="width:150px;"/>
				</a>
			</h1>
			<!--/ Logo -->

			
	</div>
		<!--/ logo container-->

		<!-- separator -->
		<!--/ separator -->

		<!-- responsive menu trigger -->
<!--
		<div id="zn-res-menuwrapper">
			<a href="#" class="zn-res-trigger zn-header-icon"></a>
		</div>
-->
		<!--/ responsive menu trigger -->

		<!-- main menu -->
		<div id="main-menu" class="main-nav zn_mega_wrapper ">

			<ul id="menu-main-menu" class="main-menu zn_mega_menu">
				<li class="menu-item-has-children menu-item-mega-parent"><a href="index.html">HOME</a>

				</li>
				<li class="menu-item-has-children menu-item-mega-parent"><a href="about-me.html">ABOUT US</a>
						
				</li>
				<li class="menu-item-has-children"><a href="contact-us.html">CONTACT US</a>
					
				</li>
				<li class="menu-item-has-children"><a href="index.html">HOW IT WORKS</a>

				</li>
				<li class="menu-item-has-children"><a href="shop-landing-page-default.html">FAQS</a>
					
				</li>
				<li class="menu-item-has-children menu-item-mega-parent"><a href="index.html">TESTIMONIAL</a>
					
				</li>
				
			</ul>

  </div>
		<!--/ main menu -->

		<!-- right side -->	
		<!-- Call to action ribbon Free Quote -->
		<a href="#" id="ctabutton" class="ctabutton kl-cta-ribbon" title="GET A FREE QUOTE" target="_self"><strong>FREE</strong>QUOTE<svg version="1.1" class="trisvg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" preserveaspectratio="none" width="14px" height="5px" viewbox="0 0 14.017 5.006" enable-background="new 0 0 14.017 5.006" xml:space="preserve"><path fill-rule="evenodd" clip-rule="evenodd" d="M14.016,0L7.008,5.006L0,0H14.016z"></path></svg></a>
		<!--/ Call to action ribbon Free Quote -->

		<!-- Shop Cart -->
		<!--/ Shop Cart -->
     </div>
<!--	</div>-->
	<!--/ siteheader-container -->
</header>
<!-- / Header style 1 -->		

<!-- / Header style 1 -->		

<!-- / Header style 1 -->

		<!-- Slideshow - Static content Text with register + bottom mask style 3 -->
		<div class="kl-slideshow static-content__slideshow nobg maskcontainer--mask3 ">
			<div class="bgback">
			</div>

			<!-- Static content wrapper with custom height 820px = .h-820 -->
			<div class="kl-slideshow-inner static-content__wrapper static-content--height min-820">
				<!-- Static content background source -->
				<div class="static-content__source">
					<!-- Background -->
					<div class="kl-bg-source">
						<!-- Background image -->
						<div class="kl-bg-source__bgimage" style="background-image:url(images/t3.jpg); background-repeat:repeat; background-attachment:scroll; background-position-x:center; background-position-y:center; background-size:cover">
						</div>
						<!--/ Background image -->

						<!-- Color overlay -->
						<div class="kl-bg-source__overlay" style="background-color:rgba(0,0,0,0.2)">
						</div>
						<!--/ Color overlay -->
					</div>
					<!--/ Background -->

					<!-- Animated Sparkles -->
					<div class="th-sparkles"></div>
					<!--/ Animated Sparkles -->
				</div>
				<!--/ .static-content__source -->

				<!-- Static content container -->
				<div class="static-content__inner container">
					<!-- Container with safe padding custom top 230px -->
					<div class="kl-slideshow-safepadding sc__container ptop-230">
						<!-- Default style with login -->
						<div class="static-content default-style static-content--with-login">
							<div class="row">
								<!-- Section left -->
								<div class="col-sm-10 col-sm-offset-1 col-md-7 col-md-offset-0">
									<!-- Title -->
									<h2 class="static-content__title">SMILESTEADILY</h2>

									<!-- Sub-title -->
									<h3 class="static-content__subtitle"><span class="fw-thin">Putting unending smile on people's faces. This is a platform whereby,<span class="fw-semibold">you can give smiles as help</span> in return gain 100% of the smiles (help) as return on <span class="fw-semibold">Investment</span>!</span></h3>
								</div>
								<!--/ Section left col-sm-10 col-sm-offset-1 col-md-7 col-md-offset-0 -->

								<!-- Section right -->
								<div class="col-sm-10 col-sm-offset-1 col-md-5 col-md-offset-0">
									<!-- Fancy register form -->
									<div class="fancy_register_form">
										<!-- Title centered -->
										<h4 style="text-align:center">Create <strong>your account</strong> now</h4>
										<form name="login_form" method="post" class="th-register-form register_form_static form-horizontal" action="#">
											<div class="form-group">
												<label class="col-sm-4 control-label" for="user_login">Username</label>
												<div class="col-sm-8">
													<input type="text" name="user_login" id="user_login" class="form-control inputbox" required="" placeholder="Mobile Number">
												</div>
											</div>
											<div class="form-group">
												<label class="col-sm-4 control-label" for="user_email">Email</label>
												<div class="col-sm-8">
													<input type="email" name="user_email" id="user_email" class="form-control inputbox required" placeholder="Your email">
												</div>
											</div>
											<div class="form-group">
												<label class="col-sm-4 control-label" for="user_password">Your password</label>
												<div class="col-sm-8">
													<input type="password" name="user_password" id="user_password" class="form-control inputbox" required="" placeholder="Your password">
												</div>
											</div>
											<div class="form-group">
												<label class="col-sm-4 control-label" for="user_password2">Verify password</label>
												<div class="col-sm-8">
													<input type="password" name="user_password2" id="user_password2" class="form-control inputbox" required="" placeholder="Verify password">
												</div>
											</div>
											<div class="form-group">
												<div class="col-sm-8 col-sm-offset-4" style="margin-bottom:0;">
													<input type="submit" name="submit" class="zn_sub_button btn btn-fullcolor th-button-register" value="Sign Up">
												</div>
                                                
                                                      
                                          </div>
										</form>
									</div>
                                  <br>
                                  <div class="col-sm-4 col-sm-offset-4" style="margin-bottom:0;">
                                                  OR <a href="my-account.html"><button class="zn_sub_button btn btn-fullcolor th-button-register">Log In</button></a>
												</div>
									<!--/ .fancy_register_form -->
								</div>
								<!--/ Section right col-sm-10 col-sm-offset-1 col-md-5 col-md-offset-0 -->
							</div>
							<!--/ row -->
						</div>
						<!--/ .static-content .default-style .static-content--with-login -->
					</div>
					<!--/ Container (.sc__container) with safe padding custom top 230px -->
				</div>
				<!--/ .static-content__inner -->
			</div>
			<!--/ .static-content__wrapper -->

			<!-- Bottom mask style 3 -->
			<div class="kl-bottommask kl-bottommask--mask3">
				<svg width="5000px" height="57px" class="svgmask " viewBox="0 0 5000 57" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
					<defs>
						<filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-mask3">
							<feOffset dx="0" dy="3" in="SourceAlpha" result="shadowOffsetInner1"></feOffset>
							<feGaussianBlur stdDeviation="2" in="shadowOffsetInner1" result="shadowBlurInner1"></feGaussianBlur>
							<feComposite in="shadowBlurInner1" in2="SourceAlpha" operator="arithmetic" k2="-1" k3="1" result="shadowInnerInner1"></feComposite>
							<feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.4 0" in="shadowInnerInner1" type="matrix" result="shadowMatrixInner1"></feColorMatrix>
							<feMerge>
								<feMergeNode in="SourceGraphic"></feMergeNode>
								<feMergeNode in="shadowMatrixInner1"></feMergeNode>
							</feMerge>
						</filter>
					</defs>
					<path d="M9.09383679e-13,57.0005249 L9.09383679e-13,34.0075249 L2418,34.0075249 L2434,34.0075249 C2434,34.0075249 2441.89,33.2585249 2448,31.0245249 C2454.11,28.7905249 2479,11.0005249 2479,11.0005249 L2492,2.00052487 C2492,2.00052487 2495.121,-0.0374751261 2500,0.000524873861 C2505.267,-0.0294751261 2508,2.00052487 2508,2.00052487 L2521,11.0005249 C2521,11.0005249 2545.89,28.7905249 2552,31.0245249 C2558.11,33.2585249 2566,34.0075249 2566,34.0075249 L2582,34.0075249 L5000,34.0075249 L5000,57.0005249 L2500,57.0005249 L1148,57.0005249 L9.09383679e-13,57.0005249 Z" class="bmask-bgfill" filter="url(#filter-mask3)" fill="#f5f5f5"></path>
				</svg>
				<i class="glyphicon glyphicon-chevron-down"></i>
			</div>
			<!--/ Bottom mask style 3 -->
		</div>
		<!--/ Slideshow - Static content Text with register + bottom mask style 3 -->


		<!-- Action Box - Style 3 section with custom top padding and white background color -->
		<section class="hg_section bg-white ptop-0">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<div class="action_box style3" data-arrowpos="center" style="margin-top:-25px;">
							<div class="action_box_inner">
								<div class="action_box_content">
									<div class="ac-content-text">
										<!-- Title -->
										<h4 class="text"><span class="fw-thin">SMILESTEADILY  <span class="fw-semibold">To create a sustainable,  </span> rewarding & unequalled donating platform</span></h4>
										<!--/ Title -->

										<!-- Sub-Title -->
										<h5 class="ac-subtitle">that will bring financial success to all and sundry</h5>
										<!--/ Sub-Title -->
									</div>

									<!-- Call to Action buttons -->
									<div class="ac-buttons">
										<a class="btn btn-lined ac-btn" href="#" target="_blank">SIGN UP NOW</a>
									</div>
									<!--/ Call to Action buttons -->
								</div>
								<!--/ action_box_content -->
							</div>
							<!--/ action_box_inner -->
						</div>
						<!--/ action_box style3 -->
					</div>
					<!--/ col-md-12 col-sm-12 -->
				</div>
				<!--/ row -->
			</div>
			<!--/ container -->
		</section>
		<!--/ Action Box - Style 3 section with custom top padding and white background color -->

		<!-- Title - Style 1 section with custom top padding -->
		<section class="hg_section bg-white ptop-65">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<!-- Title element -->
						<div class="kl-title-block clearfix text-center tbk-symbol-- tbk-icon-pos--after-title">
							<!-- Title with montserrat font, custom font size and line height, bold style and light gray color -->
							<h3 class="tbk__title montserrat fs-44 lh-44 fw-bold light-gray3">ABOUT US | @ Smilesteadily?</h3>
							<!--/ Title with montserrat font, custom font size and line height, bold style and light gray color -->

                          
                          
                          
                          
							<!-- Sub-Title with custom font size an very thin style -->
							<h4 class="tbk__subtitle fs-18 fw-vthin">Well, lots of reasons, but most importantly because..</h4>
							<!--/ Sub-Title with custom font size an very thin style -->
						</div>
						<!--/ Title element -->
					</div>
					<!--/ col-md-12 col-sm-12 -->
				</div>
				<!--/ row -->
			</div>
			<!--/ container -->
          						<!-- Title style 2 -->
						<div class="kl-title-block clearfix text-center pb-20" >
							
							<h4 class="kl-iconbox__desc fs-14 gray">
                          SMILESTEADILY is a peer-to-peer donating platform that is created out of unbridled passion to see a society where every man will enjoy financial success regardless of age, sex or social class. This is a platform where one gets double of whatever sum donated to a fellow participant in the next 15 days after payment confirmation. This translates to a whopping 100% returns on your donation. It is our will and plan to create a platform that will be sustainable, rewarding and where participants can donate confidently with hope of getting their returns without any form of hassles. We are not driven by greed but selflessness. Our footprints will be engraved on the sand of time , as we are poised to put lasting smile on the faces of our participants across board.
                            </h4>
						</div>
						<!--/ Title style 2 -->
          
          <div class="">
          <div class="ac-buttons">
            <center><a class="btn  btn-danger  ac-btn" href="{{URL:to('/about')}}" target="_blank">LEARN MORE</a></center>
		 </div>
          </div>
          
		</section>
		<!--/ Title - Style 1 section with custom top padding -->

      
      
      


		<!-- Services section -->
		<section class="hg_section bg-white pt-50 pb-100">
			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 mb-40">
						<!-- Kallyas icon -->

						<!--/ Kallyas icon -->

						<!-- Title style 2 -->
						<div class="kl-title-block clearfix text-center pb-20">
							<h3 class="tbk__title montserrat fs-26 fw-normal dark-gray mb-20"> HOW IT WORKS <a name="hiw">.</a></h3>
							<h4 class="tbk__subtitle fw-thin">
                          
                            smilesteadily.com is a noble P2P Donation Platform that delivers 100% returns in 15 days for its participants. Our special terms are GS &amp; RS
                            <br><br>
                            GS <strong style="color:red;">GIVE SMILE</strong> | RS <strong style="color:red;">RECEIVE SMILE</strong>
                          
                            </h4>
                            <br>
                            <br>
                            <p>It employs an INSURANCE DOWN PAYMENT of 20% &amp; RECOMMITMENT FEE of 20% of the total GIVE SMILE (GS) value in order to ensure commitment, sustainability and longevity which are vital parts of our core values. What this implies is that, every participant will have 20% of his total GIVE SMILE (GS) matched for pay-out almost immediately after registration while 20% of his total RECEIVE SMILE (RS) cash-out will be retained in the system, but to be released by next RS date. Any matured RS to be cashed out is dependent upon confirmation of 20% DOWN PAYMENT of a new GS.</p>
						</div>
						<!--/ Title style 2 -->

						<div class="hg_separator"></div>
					</div>
					<!--/ col-md-10 col-md-offset-1 -->

					<div class="col-md-6">
						<div class="text-right mb-80 mb-xs-40 clearfix">
							<!-- Icon wrapper -->
							<div class="kl-iconbox__icon-wrapper ml-xs-0 text-center-xs">
								<img class="kl-iconbox__icon agency-icons pull-right pull-none-xs" src="images/set-03-02.svg" alt="Iconic Awarded Design">
							</div>
							<!--/ Icon wrapper -->

							<!-- Title -->
							<h3 class="fs-l fw-bold text-center-xs">Sign Up</h3>

							<!-- Description -->
							<p class="text-gray text-center-xs">Log on to: smilesteadily.com and sign up with your correct details by imputing valid Email Address and Mobile Number. A unique VERIFICATION CODE will be sent to your given mobile number to complete your registration. Always ensure that DND is inactive on such mobile number to be used for the registration. Then, proceed to enter your banking details in the appropriate column and save. This step makes you an eligible participant on the platform.</p>
						</div>
						<!--/ text-right mr-20 mr-xs-0 mb-80 mb-xs-40 clearfix -->
					</div>
					<!--/ col-md-6 -->

					<div class="col-md-6">
						<div class="mb-80 mb-xs-40 clearfix">
							<!-- Icon wrapper -->
							<div class="kl-iconbox__icon-wrapper ml-xs-0 text-center-xs">
								<img class="kl-iconbox__icon agency-icons pull-left pull-none-xs" src="images/set-03-03.svg" alt="Iconic Awarded Design">
							</div>
							<!--/ Icon wrapper -->

							<!-- Title -->
							<h3 class="fs-l fw-bold text-center-xs">Give Smiles</h3>

							<!-- Description -->
							<p class="text-gray text-center-xs">Click on GIVE SMILE (GS) and enter the desired amount of smile that you wish to give to a fellow participant. Click on save and the GIVE SMILE (GS) Amount is recorded by the system. Note that the value should be imputed in figures without any sign. For example, a sum of Fifty Thousand Naira should be imputed as: 50000. Every participant has 48 HOURS payment time with a one-time extension of 24 hours. Always endeavour to pay earlier to avoid late confirmation.</p>
						</div>
						<!--/ ml-20 mb-80 ml-xs-0 mb-xs-40 clearfix -->
					</div>
					<!--/ col-md-6 -->

					<div class="col-md-6">
						<div class="text-right mb-80 mb-xs-40 clearfix">
							<!-- Icon wrapper -->
							<div class="kl-iconbox__icon-wrapper ml-xs-0 text-center-xs">
								<img class="kl-iconbox__icon agency-icons pull-right pull-none-xs" src="images/set-03-04.svg" alt="Iconic Awarded Design">
							</div>
							<!--/ Icon wrapper -->

							<!-- Title -->
							<h3 class="fs-l fw-bold text-center-xs">Connected</h3>

							<!-- Description -->
							<p class="text-gray text-center-xs">Immediately, the details of the person to receive 20% of your SMILE will reflect on the dashboard. Click on the name to get the person's account details.</p>
						</div>
						<!--/ text-right mr-20 mr-xs-0 mb-80 mb-xs-40 clearfix -->
					</div>
					<!--/ col-md-6 -->

					<div class="col-md-6">
						<div class="mb-80 mb-xs-40 clearfix">
							<!-- Icon wrapper -->
							<div class="kl-iconbox__icon-wrapper ml-xs-0 text-center-xs">
								<img class="kl-iconbox__icon agency-icons pull-left pull-none-xs p-22" src="images/set-03-01.svg" alt="Iconic Awarded Design">
							</div>
							<!--/ Icon wrapper -->

							<!-- Title -->
							<h3 class="fs-l fw-bold text-center-xs">Take Action</h3>

							<!-- Description -->
							<p class="text-gray text-center-xs">Give your 20% smile to the receiver by making the payment and then proceed to upload your ORIGINAL PROOF OF PAYMENT (POP) only for confirmation. Uploading of any other image aside the original POP should be totally avoided.</p>
						</div>
						<!--/ text-right mr-20 mr-xs-0 mb-80 mb-xs-40 clearfix -->
					</div>
					<!--/ col-md-6 -->
                  
                  <div class="col-md-6">
						<div class="text-right mb-80 mb-xs-40 clearfix">
							<!-- Icon wrapper -->
							<div class="kl-iconbox__icon-wrapper ml-xs-0 text-center-xs">
								<img class="kl-iconbox__icon agency-icons pull-right pull-none-xs" src="images/ib-ico-5.svg" alt="Iconic Awarded Design">
							</div>
							<!--/ Icon wrapper -->

							<!-- Title -->
							<h3 class="fs-l fw-bold text-center-xs">Step to ROI</h3>

							<!-- Description -->
							<p class="text-gray text-center-xs">After your 20% Smile given has been confirmed, your 15 days starts counting and your Receive Smile (RS) Date will be displayed on your dashboard. Then, continually check your dashboard/account at least twice daily to know whenever your remaining 90% smile is matched to avoid a default. Any default attract total BAN of the defaulter's account from the system.</p>
						</div>
						<!--/ text-right mr-20 mr-xs-0 mb-80 mb-xs-40 clearfix -->
					</div>
					<!--/ col-md-6 -->

                  <div class="col-md-6">
						<div class="mb-80 mb-xs-40 clearfix">
							<!-- Icon wrapper -->
							<div class="kl-iconbox__icon-wrapper ml-xs-0 text-center-xs">
								<img class="kl-iconbox__icon agency-icons pull-left pull-none-xs p-22" src="images/ib-ico-12.svg" alt="Iconic Awarded Design">
							</div>
							<!--/ Icon wrapper -->

							<!-- Title -->
							<h3 class="fs-l fw-bold text-center-xs">Receive Smiles</h3>

							<!-- Description -->
							<p class="text-gray text-center-xs"> Then, wait patiently to Receive your own smile (RS) on your due RS date. Fellow participant(s) will be matched to give you SMILE as generated by the system on your due date after the 20% of your new GS has been confirmed.</p>
						</div>
						<!--/ text-right mr-20 mr-xs-0 mb-80 mb-xs-40 clearfix -->
					</div>
					<!--/ col-md-6 -->
                  
                  
                  
      
                  
                  
                  
                  

					
				</div>
				<!--/ row -->
			</div>
			<!--/ container -->
		</section>
		<!--/ Services section -->
      
      
		
		<!-- Media Container - Border Animate Style 2 section with background white color -->
		<section class="hg_section bg-white p-0">
			<div class="full_width">
				<div class="row gutter-lg">
					<div class="col-md-5 col-sm-12">
						<!-- Media container style 2 element - with custom height(.h-615) -->
						<div class="media-container style2 h-615">
							<!-- Background -->
							<div class="kl-bg-source">
								<!-- Background image -->
								<div class="kl-bg-source__bgimage" style="background-image:url(images/t5.jpg); background-repeat:no-repeat; background-attachment:scroll; background-position-x:center; background-position-y:top; background-size:cover">
								</div>
								<!--/ Background image -->

								<!-- Gradient overlay -->
								<div class="kl-bg-source__overlay" style="background:rgba(137,173,178,0.3); background: -moz-linear-gradient(left, rgba(137,173,178,0.3) 0%, rgba(53,53,53,0.65) 100%); background: -webkit-gradient(linear, left top, right top, color-stop(0%,rgba(137,173,178,0.3)), color-stop(100%,rgba(53,53,53,0.65))); background: -webkit-linear-gradient(left, rgba(137,173,178,0.3) 0%,rgba(53,53,53,0.65) 100%); background: -o-linear-gradient(left, rgba(137,173,178,0.3) 0%,rgba(53,53,53,0.65) 100%); background: -ms-linear-gradient(left, rgba(137,173,178,0.3) 0%,rgba(53,53,53,0.65) 100%); background: linear-gradient(to right, rgba(137,173,178,0.3) 0%,rgba(53,53,53,0.65) 100%); ">
								</div>
								<!--/ Gradient overlay -->
							</div>
							<!--/ Background -->

							<!-- media container link button -->
							<a class="media-container__link media-container__link--btn media-container__link--style-borderanim2 " href="https://www.youtube.com/watch?v=cVt-3vbENOQ" data-lightbox="iframe">
								<!-- SVG border -->
								<div class="borderanim2-svg">
									<!-- svg -->
									<svg height="70" width="400" xmlns="http://www.w3.org/2000/svg">
										<rect class="borderanim2-svg__shape" height="70" width="400"></rect>
									</svg>
									<!--/ svg -->

									<!-- Title text -->
									<span class="media-container__text">Smilesteadily </span>
									<!--/ Title text -->
								</div>
								<!--/ SVG border -->
							</a>
							<!--/ media container link button -->
						</div>
						<!--/ media-container style2 h-615 -->
					</div>
					<!--/ col-md-5 col-sm-12 -->

                  <div class="col-md-4 col-sm-4">
						<!-- Text box element -->
						<div class="text_box">
                          
                     
                          <h5 class="fs-l fw-bold text-center small">SUSTAINABILITY </h5>
							<p>This platform is created to stand a test of time and proper plan and systems have been put in place to ensure its sustainability. Your donation can't be safer anywhere than in SMILESTEADILY.</p>
                          
                          <h3 class="fs-l fw-bold text-center small">CONSISTENCY </h3>
							<p> We will always ensure that our participants smile always by getting returns on their donations. Their payments will be consistent, as we are selfless, effective and efficient in our service delivery and platform management.</p>
						</div>
						<!--/ Text box element -->	
					</div>
					<!--/ col-md-4 col-sm-4 -->

					<div class="col-md-4 col-sm-4">
						<!-- Text box element -->
						<div class="text_box">
                          
                          <h3 class="fs-l fw-bold text-center small">SATISFACTION</h3>
							<p> We respect our participants and as a result of this, their utmost satisfaction is our priority. We shall always improve in all necessary areas to make YOU smile steadily</p>
                          
                          <h3 class="fs-l fw-bold text-center small">FIDELITY </h3>
							<p>  We appreciate the trust our participants have on this platform, and as a result of this we will constantly deliver the without blemish. We shall always keep our words.</p>
						</div>
						<!--/ Text box element -->
					</div>
					<!--/ col-md-4 col-sm-4 -->
				</div>
				<!--/ row gutter-lg -->
			</div>
			<!--/ full_width -->
		</section>
		<!--/ Media Container - Border Animate Style 2 section with background white color -->

		
		<!-- Step boxes style 2 (go boxes) element section with white background and custom bottom padding -->
		<section class="hg_section bg-white pbottom-80">
			<div class="container">
				<div class="row gutter-md">
					<div class="col-sm-4">
						<!-- Step box element #2 (First Go box) -->
						<div class="gobox gobox-first ">
							<!-- Content -->
							<div class="gobox-content">
								<!-- Title -->
								<h4>sign up </h4>
								<!--/ Title -->

								<!-- Link -->
								<a class="step_link" href="#" target="_blank"></a>
								<!--/ Link -->

								<!-- Description -->
								<p>
									Sign up with your correctly by imputing valid Email and Mobile Number
								</p>
								<!--/ Description -->
							</div>
							<!--/ Content -->
						</div>
						<!--/ Step box element #2 (First Go box) -->
					</div>
					<!--/ col-sm-4 -->

					<div class="col-sm-4">
						<!-- Step box #2 (Second Go box) -->
						<div class="gobox ">
							<!-- Content -->
							<div class="gobox-content">
								<!-- Title -->
								<h4>give smiles</h4>
								<!--/ Title -->

								<!-- Link -->
								<a class="step_link" href="#" target="_blank"></a>
								<!--/ Link -->

								<!-- Description -->
								<p>
									GIVE SMILE (GS) and enter a desired amount of smile that you wish to give to a fellow participant.
								</p>
								<!--/ Description -->
							</div>
							<!--/ Content -->
						</div>
						<!--/ Step box #2 (Second Go box) -->
					</div>
					<!--/ col-sm-4 -->

					<div class="col-sm-4">
						<!-- Step box #2 (Last Go box) -->
						<div class="gobox ok gobox-last">
							<!-- Icon = .glyphicon-ok-circle -->
							<span class="glyphicon glyphicon-ok-circle"></span>
							<!--/ Icon = .glyphicon-ok-circle -->

							<!-- Content -->
							<div class="gobox-content">
								<!-- Title -->
								<h4>receive smiles</h4>
								<!--/ Title -->

								<!-- Link -->
								<a class="step_link" href="#" target="_blank"></a>
								<!--/ Link -->

								<!-- Description -->
								<p>
									Then, wait patiently to Receive your own smile (RS) on your due RS date. 
								</p>
								<!--/ Description -->
							</div>
							<!--/ Content -->
						</div>
						<!--/ Step box #2 (Last Go box) -->
					</div>
					<!--/ col-sm-4 -->
				</div>
				<!--/ row gutter-md -->
			</div>
			<!--/ container -->
		</section>
		<!--/ Step boxes style 2 (go boxes) element section with white background and custom bottom padding -->
      
		<!-- Latest Posts - Accordion Style section -->
		<section class="hg_section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<!-- Latest posts accordion style -->
						<div class="latest_posts acc-style">
							<!-- Title -->
							<h3 class="m_title">OUR LATEST STORIES</h3>
							<!--/ Title -->

							<!-- View all posts button -->
							<a href="#" class="viewall">VIEW ALL -</a>
							<!--/ View all posts button -->

							<!-- CSS3 Accordion -->
							<div class="css3accordion">
								<ul>
									<!-- Post -->
									<li>
										<!-- Post wrapper -->
										<div class="inner-acc" style="width: 570px;">
											<!-- Post link wrapper -->
											<a href="blog-post.html" class="thumb hoverBorder plus">
												<!-- Border wrapper -->
												<span class="hoverBorderWrapper">
													<!-- Image -->
													<img src="images/sliders/iosmain.jpg" alt="" title="" />
													<!--/ Image -->

													<!-- Hover border/shadow -->
													<span class="theHoverBorder"></span>
													<!--/ Hover border/shadow -->
												</span>
												<!--/ Border wrapper -->
											</a>
											<!-- Post link wrapper -->

											<!-- Post content -->
											<div class="content">
												<!-- Details & tags -->
												<em>21 August 2017 by danut, in Mobile</em>
												<!--/ Details & tags -->

												<!-- Title with link -->
												<h5 class="m_title"><a href="blog-post.html">Enthusiastically administrate ubiquitous</a></h5>
												<!--/ Title with link -->

												<!-- Content text -->
												<div class="text">
													Competently leverage other’s high standards in customer service after supe...
												</div>
												<!--/ Content text -->

												<!-- Read more button -->
												<a href="blog-post.html">READ MORE +</a>
												<!--/ Read more button -->
											</div>
											<!--/ Post content -->
										</div>
										<!--/ Post wrapper -->
									</li>
									<!--/ Post -->

									<!-- Post -->
									<li>
										<!-- Post wrapper -->
										<div class="inner-acc" style="width: 570px;">
											<!-- Post link wrapper -->
											<a href="blog-post.html" class="thumb hoverBorder plus">
												<!-- Border wrapper -->
												<span class="hoverBorderWrapper">
													<!-- Image -->
													<img src="images/t4.jpg" alt="" title="" />
													<!--/ Image -->

													<!-- Hover border/shadow -->
													<span class="theHoverBorder"></span>
													<!--/ Hover border/shadow -->
												</span>
												<!--/ Border wrapper -->
											</a>
											<!--/ Post link wrapper -->

											<!-- Post content -->
											<div class="content">
												<!-- Details & tags -->
												<em>07 August 2017 by Marius H., in Mobile,Technology</em>
												<!--/ Details & tags -->

												<!-- Title with link -->
												<h5 class="m_title"><a href="blog-post.html">Uniquely productize next-generation opportunities</a></h5>
												<!--/ Title with link -->

												<!-- Content text -->
												<div class="text">
													Appropriately pontificate synergistic para digms whereas 24/7 “outside the...
												</div>
												<!--/ Content text -->

												<!-- Read more button -->
												<a href="blog-post.html">READ MORE +</a>
												<!--/ Read more button -->
											</div>
											<!--/ Post content -->
										</div>
										<!--/ Post wrapper -->
									</li>
									<!--/ Post -->

									<!-- Post -->
									<li class="last">
										<!-- Post wrapper -->
										<div class="inner-acc" style="width: 570px;">
											<!-- Post link wrapper -->
											<a href="blog-post.html" class="thumb hoverBorder plus">
												<!-- Border wrapper -->
												<span class="hoverBorderWrapper">
													<!-- Image -->
													<img src="images/t1.jpg" alt="" title="" />
													<!--/ Image -->

													<!-- Hover border/shadow -->
													<span class="theHoverBorder"></span>
													<!--/ Hover border/shadow -->
												</span>
												<!--/ Border wrapper -->
											</a>
											<!--/ Post link wrapper -->

											<!-- Post content -->
											<div class="content">
												<!-- Details & tags -->
												<em>07 August 2017 by Marius H., in Mobile,Networking</em>
												<!--/ Details & tags -->

												<!-- Title with link -->
												<h5 class="m_title"><a href="blog-post.html">Progressively repurpose cutting-edge models</a></h5>
												<!--/ Title with link -->

												<!-- Content text -->
												<div class="text">
													Seamlessly orchestrate process-centric best practices with end-to-end catalysts ...
												</div>
												<!--/ Content text -->

												<!-- Read more button -->
												<a href="blog-post.html">READ MORE +</a>
												<!--/ Read more button -->
											</div>
											<!--/ Post content -->
										</div>
										<!--/ Post wrapper -->
									</li>
									<!--/ Post -->
								</ul>
							</div>
							<!--/ CSS3 Accordion -->
						</div>
						<!--/ Latest posts accordion style -->
					</div>
					<!--/ col-md-12 col-sm-12 -->
				</div>
				<!--/ row -->
			</div>
			<!--/ hg_section_size container -->
		</section>
		<!--/ Latest Posts - Accordion Style section -->

		<!-- Partners & Testimonials section with custom paddings -->
		<section class="hg_section hg_section--relative ptop-80 pbottom-80">
			<!-- Background -->
			<div class="kl-bg-source">
				<!-- Gradient overlay -->
				<div class="kl-bg-source__overlay" style="background:rgba(205,33,34,1); background: -moz-linear-gradient(left, rgba(205,33,34,1) 0%, rgba(245,72,76,1) 100%); background: -webkit-gradient(linear, left top, right top, color-stop(0%,rgba(205,33,34,1)), color-stop(100%,rgba(245,72,76,1))); background: -webkit-linear-gradient(left, rgba(205,33,34,1) 0%,rgba(245,72,76,1) 100%); background: -o-linear-gradient(left, rgba(205,33,34,1) 0%,rgba(245,72,76,1) 100%); background: -ms-linear-gradient(left, rgba(205,33,34,1) 0%,rgba(245,72,76,1) 100%); background: linear-gradient(to right, rgba(205,33,34,1) 0%,rgba(245,72,76,1) 100%); ">
				</div>
				<!--/ Gradient overlay -->
			</div>
			<!--/ Background -->

			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<!-- Title element with bottom line style -->
						<div class="kl-title-block clearfix text-center tbk-symbol--line tbk-icon-pos--after-title">
							<!-- Title with montserrat font, white color and bold style -->
							<h3 class="tbk__title white montserrat fw-bold">TESTIMONIALS</h3>
							<!--/ Title with montserrat font, white color and bold style -->

							<!-- Title bottom symbol -->
							<div class="tbk__symbol ">
								<span></span>
							</div>
							<!--/ Title bottom symbol -->
						</div>
						<!--/ Title element with bottom line style -->

						<!-- Testimonials & Partners element - light text style -->
						<div class="testimonials-partners testimonials-partners--light">
							<!-- Testimonials  element-->
							<div class="ts-pt-testimonials clearfix">
								<!-- Item - size 2 and normal style with custom margin top -->
								
								<!--/ Item - size 2 and normal style with custom margin top - .ts-pt-testimonials__item -->

								<!-- Item - size 1 and normal style -->
								<div class="ts-pt-testimonials__item ts-pt-testimonials__item--size-1 ts-pt-testimonials__item--normal" style=" ">
									<!-- Testimonial text -->
									<div class="ts-pt-testimonials__text">
										“Before my business cannot give me food three times a day. Now I am happy because I am about to roof my house.
									</div>
									<!--/ Testimonial text -->

									<!-- Testimonials info -->
									<div class="ts-pt-testimonials__infos ts-pt-testimonials__infos--">
										<!-- User image -->
										<div class="ts-pt-testimonials__img" style="background-image:url('images/t1.jpg');" title="PERRY ANDREWS">
										</div>
										<!--/ User image -->

										<!-- Name -->
										<h4 class="ts-pt-testimonials__name">BOSE ALUKO</h4>
										<!--/ Name -->

										<!-- Position -->
										<div class="ts-pt-testimonials__position">
											ROADSIDE BOLI .
										</div>
										<!--/ Position -->

										<!--/ Review stars - 4 stars -->
										<div class="ts-pt-testimonials__stars ts-pt-testimonials__stars--4">
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
										</div>
										<!--/ Review stars - 4 stars -->
									</div>
									<!--/ Testimonials info - .ts-pt-testimonials__infos -->
								</div>
								<!--/ Item - size 1 and normal style - .ts-pt-testimonials__item -->

								<!-- Item - size 1 and reversed style -->
								<div class="ts-pt-testimonials__item ts-pt-testimonials__item--size-1 ts-pt-testimonials__item--reversed" style=" ">
									<!-- Testimonial info -->
									<div class="ts-pt-testimonials__infos ts-pt-testimonials__infos--">
										<!-- User image -->
										<div class="ts-pt-testimonials__img" style="background-image:url('images/t3.jpg');" title="SAMMY BROWNS">
										</div>
										<!--/ User image -->

										<!-- Name -->
										<h4 class="ts-pt-testimonials__name">CYNTHIA BROWNS</h4>
										<!--/ Name -->

										<!-- Position -->
										<div class="ts-pt-testimonials__position">
											CFO, Perfect Inc.
										</div>
										<!--/ Position -->

										<!-- Review stars - 5 stars -->
										<div class="ts-pt-testimonials__stars ts-pt-testimonials__stars--5">
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
											<span class="glyphicon glyphicon-star"></span>
										</div>
										<!--/ Review stars - 5 stars -->
									</div>
									<!--/ Testimonial info - .ts-pt-testimonials__infos -->

									<!-- Testimonial text -->
									<div class="ts-pt-testimonials__text">
										“It is a leverage for me. I took a bold and couragious step hoping for the best. I found fidelity in this platform. A trusted one.
									</div>
									<!--/ Testimonial text -->
								</div>
								<!--/ Item - size 1 and reversed style - .ts-pt-testimonials__item -->
							</div>
							<!--/ Testimonials element - .ts-pt-testimonials-->

							<!-- Separator for testimonials-partners elements -->
							<!--/ Separator for testimonials-partners elements -->

							<!-- Partners element -->
							
							<!--/ Partners element - .ts-pt-partners -->
						</div>
						<!--/ Testimonials & Partners element - light text style -->
					</div>
					<!--/ col-md-12 col-sm-12 -->
				</div>
				<!--/ row -->
			</div>
			<!--/ container -->
		</section>
		<!--/ Partners & Testimonials section with custom paddings -->

		

<!-- Footer - Default Style -->
		<div id="dp-js-footer-helper" style="height:0 !important; display:none !important;"></div>
		<footer id="footer">
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div>
							<h3 class="title m_title">FOOTER MENU</h3>
							<div class="sbs">
								<ul class="menu">
									<li><a href="index.html">HOME</a></li>
									<li><a href="about-me.html">ABOUT US</a></li>
									<li><a href="contact-us.html">CONTACT US</a></li>
									<li><a href="index.html">HOW IT WORKS</a></li>
									<li><a href="index.html">FAQS</a></li>
									<li><a href="index.html">TESTIMONIALS</a></li>
								</ul>
							</div>
						</div>
					</div>
					<!--/ col-sm-5 -->

					
					<!-- col-sm-4 -->

					<div class="col-sm-3">
						<div>
							<h3 class="title m_title">GET IN TOUCH</h3>
							<div class="contact-details"><p><strong>T (212) 555 55 00</strong><br>
								Email: <a href="#">info@smilesteadily.com</a></p>
								<p>Smilesteadily LTD<br>
								Lagos</p>
								
							</div>
						</div>
					</div>
					<!--/ col-sm-3 -->
				</div>
				<!--/ row -->

				

				<div class="row">
					<div class="col-sm-12">
						<div class="bottom clearfix">
							<!-- social-icons -->
							<ul class="social-icons sc--clean clearfix">
								<li class="title">GET SOCIAL</li>
								<li><a href="#" target="_self" class="icon-facebook" title="Facebook"></a></li>
								<li><a href="#" target="_self" class="icon-twitter" title="Twitter"></a></li>	
								<li><a href="#" target="_self" class="icon-dribbble" title="Dribbble"></a></li>
								<li><a href="#" target="_blank" class="icon-google" title="Google Plus"></a></li>
							</ul>
							<!--/ social-icons -->

							<!-- copyright -->
							<div class="copyright">
								<a href="index.html">
									<img src="images/smilelog-mini.png" alt="Kallyas Demo">
								</a>
								<p>© 2017 All rights reserved. <a href="http://smilesteadily.com">Smilesteadily LTD</a>.</p>
							</div>
							<!--/ copyright -->
						</div>
						<!--/ bottom -->
					</div>
					<!--/ col-sm-12 -->
				</div>
				<!--/ row -->
			</div>
			<!--/ container -->
		</footer>
		<!--/ Footer - Default Style -->
	</div>
	<!--/ Page Wrapper -->


	

	<!-- Login Panel content -->
	<div id="login_panel" class="mfp-hide loginbox-popup auth-popup">
		<div class="inner-container login-panel auth-popup-panel">
			<h3 class="m_title m_title_ext text-custom auth-popup-title tcolor">SIGN IN YOUR ACCOUNT TO HAVE ACCESS TO DIFFERENT FEATURES</h3>
			<form class="login_panel" name="login_form" method="post" action="#">
				<div class="form-group kl-fancy-form">
					<input type="text" id="kl-username" name="log" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="eg: james_smith">
					<label class="kl-font-alt kl-fancy-form-label">USERNAME</label>
				</div>
				<div class="form-group kl-fancy-form">
					<input type="password" id="kl-password" name="pwd" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="type password">
					<label class="kl-font-alt kl-fancy-form-label">PASSWORD</label>
				</div>
				<label class="auth-popup-remember" for="kl-rememberme"><input type="checkbox" name="rememberme" id="kl-rememberme" value="forever" class="auth-popup-remember-chb"> Remember Me </label>
				<input type="submit" id="login" name="submit_button" class="btn zn_sub_button btn-fullcolor btn-md" value="LOG IN">
				<input type="hidden" value="login" class="" name="form_action"><input type="hidden" value="login" class="" name="action">
				<input type="hidden" value="#" class="" name="submit">
				<div class="links auth-popup-links">
					<a href="#register_panel" class="create_account auth-popup-createacc kl-login-box auth-popup-link">CREATE AN ACCOUNT</a><span class="sep auth-popup-sep"></span><a href="#forgot_panel" class="kl-login-box auth-popup-link">FORGOT YOUR PASSWORD?</a>
				</div>
			</form>
		</div>
		<button title="Close (Esc)" type="button" class="mfp-close">×</button>
	</div>
	<div id="register_panel" class="mfp-hide loginbox-popup auth-popup">
		<div class="inner-container register-panel auth-popup-panel">
			<h3 class="m_title m_title_ext text-custom auth-popup-title">CREATE ACCOUNT</h3>
			<form class="register_panel" name="login_form" method="post" action="#">
				<div class="form-group kl-fancy-form ">
					<input type="text" id="reg-username" name="user_login" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="type desired username"><label class="kl-font-alt kl-fancy-form-label">USERNAME</label>
				</div>
				<div class="form-group kl-fancy-form">
					<input type="text" id="reg-email" name="user_email" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="your-email@website.com"><label class="kl-font-alt kl-fancy-form-label">EMAIL</label>
				</div>
				<div class="form-group kl-fancy-form">
					<input type="password" id="reg-pass" name="user_password" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="*****"><label class="kl-font-alt kl-fancy-form-label">PASSWORD</label>
				</div>
				<div class="form-group kl-fancy-form">
					<input type="password" id="reg-pass2" name="user_password2" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="*****"><label class="kl-font-alt kl-fancy-form-label">CONFIRM PASSWORD</label>
				</div>
				<div class="form-group">
					<input type="submit" id="signup" name="submit" class="btn zn_sub_button btn-block btn-fullcolor btn-md" value="CREATE MY ACCOUNT">
				</div>
				<div class="links auth-popup-links">
					<a href="#login_panel" class="kl-login-box auth-popup-link">ALREADY HAVE AN ACCOUNT?</a>
				</div>
			</form>
		</div>
	</div>
	<div id="forgot_panel" class="mfp-hide loginbox-popup auth-popup forgot-popup">
		<div class="inner-container forgot-panel auth-popup-panel">
			<h3 class="m_title m_title_ext text-custom auth-popup-title">FORGOT YOUR DETAILS?</h3>
			<form class="forgot_form" name="login_form" method="post" action="#">
				<div class="form-group kl-fancy-form">
					<input type="text" id="forgot-email" name="user_login" class="form-control inputbox kl-fancy-form-input kl-fw-input" placeholder="...">
					<label class="kl-font-alt kl-fancy-form-label">USERNAME OR EMAIL</label>
				</div>
				<div class="form-group">
					<input type="submit" id="recover" name="submit" class="btn btn-block zn_sub_button btn-fullcolor btn-md" value="SEND MY DETAILS!">
				</div>
				<div class="links auth-popup-links">
					<a href="#login_panel" class="kl-login-box auth-popup-link">AAH, WAIT, I REMEMBER NOW!</a>
				</div>
			</form>
		</div>
		<button title="Close (Esc)" type="button" class="mfp-close">×</button>
	</div>
	<!--/ Login Panel content -->
	

	<!-- ToTop trigger -->
	<a href="#" id="totop">TOP</a>
	<!--/ ToTop trigger -->


	


	<!-- JS FILES // These should be loaded in every page -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/kl-plugins.js"></script>

	<!-- JS FILES // Loaded on this page -->
	<!-- Requried js script for Slideshow Scroll effect -->
	<script type="text/javascript" src="js/plugins/scrollme/jquery.scrollme.js"></script>

	<!-- Required js script for iOS Slider -->
	<script type="text/javascript" src="js/plugins/_sliders/ios/jquery.iosslider.min.js"></script>

	<!-- Required js trigger for iOS Slider -->
	<script type="text/javascript" src="js/trigger/slider/ios/kl-ios-slider.js"></script>

	<!-- CarouFredSel - Required js script for Screenshot box / Partners Carousel -->
	<script type="text/javascript" src="js/plugins/_sliders/caroufredsel/jquery.carouFredSel-packed.js"></script>

	<!-- Required js trigger for Screenshot Box Carousel -->
	<script type="text/javascript" src="js/trigger/kl-screenshot-box.js"></script>

	<!-- Required js trigger for Partners Carousel -->
	<script type="text/javascript" src="js/trigger/kl-partners-carousel.js"></script>	

	<!-- Custom Smilesteadily JS codes -->
	<script type="text/javascript" src="js/kl-scripts.js"></script>

	<!-- Demo panel -->
	<script type="text/javascript" src="js/dp.js"></script>


	

</body>

<!-- Mirrored from demos.hogash.com/Smilesteadily_template/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 07 Jul 2017 10:12:11 GMT -->
</html>